#QUESTION 3
#1-
string = input("Please Enter String : ")
vowels = 0
  
for i in string
    if(i == 'a' or i == 'e' or i == 'i' or i == 'o' or i == 'u' or i == 'A'
       or i == 'E' or i == 'I' or i == 'O' or i == 'U'):
        vowels = vowels + 1
  
print("Total Number of Vowels = ", vowels)

#2-
def Sum(num):
  if num == 1:
    return 1
  return num + Sum(num-1)
num = 5
print(Sum(num))

#3-
num1=0
num2 =1
print("Fibonacci:")
for i in range(10):
    print(num1, end="  ")
result = num1 + num2
num1 = num2
num2 = result

#4-
dictionary = {'a': 100, 'b': 200, 'c': 300}
if 200 in dictionary.values():
    print('200 present in a dictionary')

#5-
class Circle:
    def __init__(self, radius, color):
        self.radius = radius
        self.color = color

    def intro(self):
        print(self.radius, self.color)

obj = Circle("1.0", "red")

class Cylinder(Circle):
    def __init__(self, radius, color):
        super().__init__(radius, color)

obj = Cylinder("1.0", "red")




#QUESTION 4
#1-
import string
import random
uppercase=list(string.ascii_uppercase)
lowercase=list(string.ascii_lowercase)
digits=list(string.digits)
def generatePass():
    passwordLength=input('Enter Password')
    password=[]
    random.shuffle(uppercase)
    random.shuffle(lowercase)
    random.shuffle(digits)
    for i in range(round(passwordLength * .4)):
        password.append(uppercase[i])
    for i in range(round(passwordLength * .3)):
        password.append(lowercase[i])
        for i in range(round(passwordLength * .3)):
            password.append(digits[i])
        print(password)
#2-
#HTML
<body>

#CSS
body {
  padding: 100px;
  background-color: white;
  color: black;
  font-size: 25px;
}

.dark-mode {
  background-color: black;
  color: white;
}
#JS
function myFunction() {
  var element = document.body;
  element.classList.toggle("dark-mode");
}

#QUESTION 5
#1-

#Default Constructor

class Test:
    def init (x):
        x.msg = "Default constructor"

    def display(x):
        print(x.msg)
    object = Test()
    object.display()

#Parameterized Constructor

class Student:
    def init(self, name, age):

        self.name = name

        self.age = age

std = Student("Mohamed", 21)
print(std.name, std.age)

#2-

class NewClass:
    "New Class"
    pass

class1 =NewClass()